/** Automatically generated file. DO NOT MODIFY */
package com.bottle.stockmanage;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}